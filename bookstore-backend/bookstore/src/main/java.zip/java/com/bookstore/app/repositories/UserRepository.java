package com.bookstore.app.repositories;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.bookstore.app.entities.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
	Optional<User> findByEmail(String email);

	boolean existsByEmail(String email);
}
