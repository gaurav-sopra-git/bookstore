package com.bookstore.app.entities;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.*;
import lombok.Getter;

@Entity
@Table(name = "customer_orders")
@Getter
public class CustomerOrder {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false, unique = true, length = 36)
	private String orderNumber;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "user_id")
	private User user;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 20)
	private OrderStatus status;
	
	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal totalAmount;
	
	@Column(nullable = false, length = 300)
	private String shippingAddress;
	
	@Column(nullable = false, updatable = false)
	private Instant createdAt;
	
	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<OrderItem> items = new ArrayList<>();

	protected CustomerOrder() {
		/* Required by JPA. */ }

	/** Expose a read-only snapshot; mutations go through domain methods. */
	public List<OrderItem> getItems() {
		return List.copyOf(items);
	}

	public static CustomerOrder place(User user, String orderNumber, String shippingAddress) {
		var order = new CustomerOrder();
		order.user = user;
		order.orderNumber = orderNumber;
		order.shippingAddress = shippingAddress.strip();
		order.status = OrderStatus.PLACED;
		order.totalAmount = BigDecimal.ZERO;
		return order;
	}

	public void addItem(OrderItem item) {
		items.add(item);
		item.attachTo(this);
		totalAmount = totalAmount.add(item.getLineTotal());
	}

	@PrePersist
	void onCreate() {
		createdAt = Instant.now();
	}
}
