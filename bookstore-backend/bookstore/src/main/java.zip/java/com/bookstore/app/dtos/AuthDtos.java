package com.bookstore.app.dtos;

import jakarta.validation.constraints.*;

public final class AuthDtos {
	
	private AuthDtos() {
	}

	public record RegisterRequest(@NotBlank @Size(max = 120) String name,
			@NotBlank @Email @Size(max = 190) String email, @NotBlank @Size(min = 8, max = 72) String password) {
	}

	public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {
	}

	public record AuthResponse(String accessToken, String tokenType, long expiresIn, UserResponse user) {
	}

	public record UserResponse(Long id, String name, String email, String role) {
	}
}
