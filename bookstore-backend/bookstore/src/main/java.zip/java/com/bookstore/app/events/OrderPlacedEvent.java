package com.bookstore.app.events;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Immutable integration event; contains identifiers and facts, not JPA
 * entities.
 */
public record OrderPlacedEvent(String orderNumber, Long customerId, BigDecimal totalAmount, Instant occurredAt) {
	
	public static OrderPlacedEvent from(String orderNumber, Long customerId, BigDecimal totalAmount) {
		return new OrderPlacedEvent(orderNumber, customerId, totalAmount, Instant.now());
	}
}
