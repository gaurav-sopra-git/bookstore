package com.bookstore.app.entities;

public enum OrderStatus {
	PLACED, CANCELLED
}
