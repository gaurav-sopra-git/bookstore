package com.bookstore.app.entities;

import java.math.BigDecimal;
import jakarta.persistence.*;
import lombok.Getter;

@Entity
@Table(name = "order_items")
@Getter
public class OrderItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "order_id")
	private CustomerOrder order;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "book_id")
	private Book book;
	
	@Column(nullable = false, length = 200)
	private String bookTitle;
	
	@Column(nullable = false, length = 150)
	private String author;
	
	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal unitPrice;
	
	@Column(nullable = false)
	private int quantity;
	
	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal lineTotal;

	protected OrderItem() {
		/* Required by JPA. */ }

	public static OrderItem snapShotOf(Book book, int quantity) {
		var item = new OrderItem();
		item.book = book;
		item.bookTitle = book.getTitle();
		item.author = book.getAuthor();
		item.unitPrice = book.getPrice();
		item.quantity = quantity;
		item.lineTotal = book.getPrice().multiply(BigDecimal.valueOf(quantity));
		return item;
	}

	void attachTo(CustomerOrder order) {
		this.order = order;
	}
}
